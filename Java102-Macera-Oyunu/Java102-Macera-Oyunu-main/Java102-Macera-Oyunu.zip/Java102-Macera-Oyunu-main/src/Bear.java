public class Bear extends Obstacle {

    public Bear() {
        super("Bear", 3, 7, 20, 12);
    }
}
