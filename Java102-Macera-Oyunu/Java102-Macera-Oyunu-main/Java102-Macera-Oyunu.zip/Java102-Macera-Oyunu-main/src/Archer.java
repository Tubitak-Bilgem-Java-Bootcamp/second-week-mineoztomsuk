public class Archer extends CharName{

    public Archer() {
        super("Archer",2,7, 18, 20);
    }
}
