public class Knight extends CharName{

    public Knight() {
        super("Knight",3,8, 24, 100);
    }
}
