public class Cave extends BattleLoc{

    public Cave(Player player) {
        super(player, "Cave", new Zombie(), "Food");
    }
}
