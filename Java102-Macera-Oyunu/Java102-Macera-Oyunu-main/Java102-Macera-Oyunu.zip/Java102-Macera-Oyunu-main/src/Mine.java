public class Mine extends BattleLoc {

    public Mine(Player player) {
        super(player, "Mine", new Snake(), "Award/Weapon/Armor");
    }
}
