public class Samurai extends CharName {

    public Samurai() {
        super("Samurai",1,5, 21, 15);
    }
}
